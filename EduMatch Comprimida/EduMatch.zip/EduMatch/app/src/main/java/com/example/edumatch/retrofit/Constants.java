package com.example.edumatch.retrofit;

public class Constants {
    public static String URL_BASE = "http://192.168.100.101:8080/";

}
